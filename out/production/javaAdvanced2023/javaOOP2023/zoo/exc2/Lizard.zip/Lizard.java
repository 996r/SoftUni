

import java.util.List;

public class Lizard extends Reptile{

    Lizard(String name){
        super(name);
    }
}
