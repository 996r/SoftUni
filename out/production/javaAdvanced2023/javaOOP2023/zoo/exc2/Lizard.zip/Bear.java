

public class Bear extends Mammal{
    Bear(String name){
        super(name);
    }
}
