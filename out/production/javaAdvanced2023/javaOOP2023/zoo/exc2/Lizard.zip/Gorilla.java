

public class Gorilla extends Mammal{
    Gorilla(String name){
        super(name);
    }
}
