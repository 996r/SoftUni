package javaOOP2023.trafficLight;

public enum Color {
    RED,
    GREEN,
    YELLOW
}
