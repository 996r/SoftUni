package climbers.models.mountain;

import java.util.ArrayList;
import java.util.Collection;

import static climbers.common.ExceptionMessages.*;

public class MountainImpl implements Mountain {
    private String name;
    Collection<String> peaksList;
    public  MountainImpl(String name){
        setName(name);
        peaksList = new ArrayList<>();
    }
    public void setName(String name){
        if(name == null || name.trim().isEmpty()){
            throw new NullPointerException(MOUNTAIN_NAME_NULL_OR_EMPTY);
        }
        this.name = name;
    }

    @Override
    public Collection<String> getPeaksList() {
        return null;
    }

    @Override
    public String getName() {
        return null;
    }
}
