package climbers.models.climber;

import climbers.models.roster.Roster;

import static climbers.common.ExceptionMessages.*;

public abstract class BaseClimber implements Climber{
    private String name;
    private double strength;
     private Roster roster;

     public BaseClimber(String name, double strength){
         setName(name);
         setStrength(strength);
     }
     public void setName(String name){
         if(name == null || name.isEmpty()){
             throw new NullPointerException(CLIMBER_NAME_NULL_OR_EMPTY);
         }
         this.name = name;
     }
     public void setStrength(double strength){
         if(strength < 0) {
             throw new IllegalArgumentException(CLIMBER_STRENGTH_LESS_THAN_ZERO);
         }
         this.strength = strength;
     }


    @Override
    public String getName() {
        return null;
    }

    @Override
    public double getStrength() {
        return 0;
    }

    @Override
    public boolean canClimb() {
        return false;
    }

    @Override
    public Roster getRoster() {
        return null;
    }

    @Override
    public void climb() {

    }
}
