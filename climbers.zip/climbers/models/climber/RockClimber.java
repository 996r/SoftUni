package climbers.models.climber;

public class RockClimber extends BaseClimber{
    private static final double ROCK_CLIMBER_STRENGTH = 120;
    public RockClimber(String name) {
        super(name, ROCK_CLIMBER_STRENGTH);
    }
}
