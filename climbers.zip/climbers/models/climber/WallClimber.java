package climbers.models.climber;

public class WallClimber extends BaseClimber{
    private static final double WALL_CLIMBER_STRENGTH = 90;
    public WallClimber(String name) {
        super(name, WALL_CLIMBER_STRENGTH);
    }
}
