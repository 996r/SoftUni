package climbers.repositories;

import climbers.models.climber.Climber;

import java.util.ArrayList;
import java.util.Collection;

public class ClimberRepository implements Repository{
    private  Collection <Climber> climbers;

    public ClimberRepository(){
        climbers = new ArrayList<>();
    }
    @Override
    public Collection getCollection() {
        return null;
    }

    @Override
    public void add(Object entity) {

    }

    @Override
    public boolean remove(Object entity) {
        return false;
    }

    @Override
    public Object byName(String name) {
        return null;
    }
}
